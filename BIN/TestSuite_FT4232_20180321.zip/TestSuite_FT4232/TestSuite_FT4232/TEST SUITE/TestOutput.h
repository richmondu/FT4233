#pragma once

void DisplayTestStart(const char* a_pcDescription);
void DisplayTestStop(bool a_bStatus);
void DisplayTestSummary(int a_iFailCount, int a_iSuccessCount);
void DisplayTestLogFile(const char* a_pcFileName);
