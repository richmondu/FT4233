#include "TestSuite.h"



int main()
{
	bool bStressTest = false;
	bool bResult = false;
	int iFailCount = 0;
	int iSuccessCount = 0;


	LOGGER_INIT((char*)TEST_LOG_FILE_NAME.c_str(), false);

	do {
		for (auto & i : TEST_CASES) {
			if (i.m_fxn == NULL) {
				break;
			}

			DisplayTestStart(i.m_dsc.c_str());
			bResult = i.m_fxn();
			DisplayTestStop(bResult);

			if (!bResult) {
				iFailCount++;
				goto exit;
			}
			iSuccessCount++;
		}
	} while (bStressTest);


exit:

	DisplayTestSummary(iFailCount, iSuccessCount);
	DisplayTestLogFile(LOGGER_FILE());
	LOGGER_FREE();

	system("pause");
	return 0;
}
