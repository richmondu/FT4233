#pragma once
#include <string>
#include <vector>
#include "TestLogger.h"
#include "TestOutput.h"



typedef bool(*TEST_FUNCTION)();

typedef struct _TEST_CASE
{
	TEST_FUNCTION	m_fxn;
	std::string		m_dsc;

} TEST_CASE;

extern std::string TEST_LOG_FILE_NAME;

extern std::vector<TEST_CASE> TEST_CASES;
