#pragma once

// From ftd2xxTest.c
bool FT4232_D2XX_Info();
bool FT4232_D2XX_Enumeration();
bool FT4232_D2XX_OpenDevice();
bool FT4232_D2XX_ResetPort();
bool FT4232_D2XX_CyclePort();
bool FT4232_D2XX_ResetDevice();

// From xxx.c

// From yyy.c

// From zzz.c

