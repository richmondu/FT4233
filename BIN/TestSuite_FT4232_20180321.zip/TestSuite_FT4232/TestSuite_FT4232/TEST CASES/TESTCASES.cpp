#include "../TEST SUITE/TestSuite.h"
#include "../TEST CASES/TestCases.h"
#include "../TEST SUITE/TestExamples.h"



// Uncomment to use the sample test cases
//#define ENABLE_SAMPLES

// Update to customize the file name of the log file
std::string TEST_LOG_FILE_NAME = "TestSuite_FT4232.log";

// Update to include all the test cases
std::vector<TEST_CASE> TEST_CASES =
{
#ifdef ENABLE_SAMPLES
	{ ExampleTest1, "ExampleTest1" },
	{ ExampleTest2, "ExampleTest2" },
	//{ ExampleTest3, "ExampleTest3" },
#endif //ENABLE_SAMPLES


	// -------------------------------------------------------------
	// Add test cases below ...
	// -------------------------------------------------------------


	{ FT4232_D2XX_Info,			"FT4232_D2XX_Info"			},
	{ FT4232_D2XX_Enumeration,	"FT4232_D2XX_Enumeration"	},
	{ FT4232_D2XX_OpenDevice,	"FT4232_D2XX_OpenDevice"	},
	{ FT4232_D2XX_ResetPort,	"FT4232_D2XX_ResetPort"		},
	{ FT4232_D2XX_CyclePort,	"FT4232_D2XX_CyclePort"		},
	{ FT4232_D2XX_ResetDevice,	"FT4232_D2XX_ResetDevice"	},


	// -------------------------------------------------------------
	// Add test cases above ...
	// -------------------------------------------------------------


	{ NULL, "" }, // Do not modify. Last test case should be NULL.
};
