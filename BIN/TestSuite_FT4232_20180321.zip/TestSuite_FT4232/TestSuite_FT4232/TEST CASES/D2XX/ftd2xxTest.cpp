#include "ftd2xx.h"
#pragma comment(lib, "ftd2xx.lib")
#include <stdio.h>


#define FT4232_DEVINFO_ID 0x04036011

bool FT4232_D2XX_Info() {

	DWORD dwDLLVersion = 0;
	FT_STATUS ftStatus = FT_GetLibraryVersion(&dwDLLVersion);
	if (ftStatus != FT_OK) {
		printf("FT_GetLibraryVersion failed! Cannot get library version!\n");
		return false;
	}
	printf("D2XX Library version=0x%08x\n", dwDLLVersion);

	return true;
}

bool FT4232_D2XX_Enumeration() {

	FT_STATUS ftStatus = 0;

	DWORD dwNumDevices = 0;
	ftStatus = FT_CreateDeviceInfoList(&dwNumDevices);
	if (ftStatus != FT_OK) {
		printf("FT_CreateDeviceInfoList failed! No devices found!\n");
		return false;
	}

	printf("DeviceCount=%d\n", dwNumDevices);
	if (dwNumDevices != 4) {
		printf("FT_CreateDeviceInfoList failed! A FT_4232 should have 4 devices enumerated!\n");
		return false;
	}

	for (DWORD i = 0; i<dwNumDevices; ++i) {
		FT_DEVICE_LIST_INFO_NODE devInfo;
		memset(&devInfo, 0, sizeof(devInfo));

		ftStatus = FT_GetDeviceInfoDetail(i, &devInfo.Flags, &devInfo.Type,
			&devInfo.ID, &devInfo.LocId,
			devInfo.SerialNumber,
			devInfo.Description,
			&devInfo.ftHandle);
		if (ftStatus != FT_OK) {
			printf("FT_GetDeviceInfoDetail failed!\n");
			return false;
		}

		printf("Dev %d:\n", i);
		printf("  ID=0x%08x\n", devInfo.ID);
		printf("  SerialNumber=%s\n", devInfo.SerialNumber);
		printf("  Description=%s\n", devInfo.Description);

		if (devInfo.ID != FT4232_DEVINFO_ID) {
			printf("FT_GetDeviceInfoDetail failed!\n");
			return false;
		}
	}

	return true;
}

bool FT4232_D2XX_OpenDevice() {

	FT_STATUS ftStatus = 0;
	FT_HANDLE ftHandle[4] = { NULL };

	DWORD dwNumDevices = 0;
	ftStatus = FT_CreateDeviceInfoList(&dwNumDevices);
	if (ftStatus != FT_OK) {
		printf("FT_CreateDeviceInfoList failed! No devices found!\n");
		return false;
	}

	if (dwNumDevices != 4) {
		printf("FT_CreateDeviceInfoList failed! A FT_4232 should have 4 devices enumerated!\n");
		return false;
	}

	for (DWORD i = 0; i<dwNumDevices; ++i) {
		FT_DEVICE_LIST_INFO_NODE devInfo;
		memset(&devInfo, 0, sizeof(devInfo));

		ftStatus = FT_GetDeviceInfoDetail(i, &devInfo.Flags, &devInfo.Type,
			&devInfo.ID, &devInfo.LocId,
			devInfo.SerialNumber,
			devInfo.Description,
			&devInfo.ftHandle);
		if (ftStatus != FT_OK) {
			printf("FT_GetDeviceInfoDetail failed!\n");
			return false;
		}

		printf("Dev %d:\n", i);
		
		ftStatus = FT_OpenEx(devInfo.SerialNumber, FT_OPEN_BY_SERIAL_NUMBER, &ftHandle[i]);
		if (ftStatus != FT_OK) {
			printf("FT_OpenEx failed! Cannot open device by SerialNumber=%s\n", devInfo.SerialNumber);
			return false;
		}
		printf("  Open device by SerialNumber=%s\n", devInfo.SerialNumber);
		FT_Close(ftHandle[i]);
		ftHandle[i] = NULL;

		ftStatus = FT_OpenEx(devInfo.Description, FT_OPEN_BY_DESCRIPTION, &ftHandle[i]);
		if (ftStatus != FT_OK) {
			printf("FT_OpenEx failed! Cannot open device by Description=%s", devInfo.Description);
			return false;
		}
		printf("  Open device by Description=%s\n", devInfo.Description);
		FT_Close(ftHandle[i]);
		ftHandle[i] = NULL;

		ftStatus = FT_Open(i, &ftHandle[i]);
		if (ftStatus != FT_OK) {
			printf("FT_Open failed! Cannot open device by Index=%d", i);
			return false;
		}
		DWORD dwDriverVersion = 0;
		ftStatus = FT_GetDriverVersion(ftHandle[i], &dwDriverVersion);
		if (ftStatus != FT_OK) {
			printf("FT_GetDriverVersion failed! Cannot get driver version!\n");
			return false;
		}
		printf("  Open device by Index=%d\n", i);
		FT_Close(ftHandle[i]);
		ftHandle[i] = NULL;

		printf("  Driver version=0x%08x\n", dwDriverVersion);
	}

	return true;
}

bool FT4232_D2XX_ResetPort() 
{
	FT_STATUS ftStatus = 0;
	FT_HANDLE ftHandle[4] = { NULL };

	DWORD dwNumDevices = 0;
	ftStatus = FT_CreateDeviceInfoList(&dwNumDevices);
	if (ftStatus != FT_OK) {
		printf("FT_CreateDeviceInfoList failed! No devices found!\n");
		return false;
	}

	if (dwNumDevices != 4) {
		printf("FT_CreateDeviceInfoList failed! A FT_4232 should have 4 devices enumerated!\n");
		return false;
	}

	for (DWORD i = 0; i<dwNumDevices; ++i) {
		FT_DEVICE_LIST_INFO_NODE devInfo;
		memset(&devInfo, 0, sizeof(devInfo));

		ftStatus = FT_GetDeviceInfoDetail(i, &devInfo.Flags, &devInfo.Type,
			&devInfo.ID, &devInfo.LocId,
			devInfo.SerialNumber,
			devInfo.Description,
			&devInfo.ftHandle);
		if (ftStatus != FT_OK) {
			printf("FT_GetDeviceInfoDetail failed!\n");
			return false;
		}

		printf("Dev %d:\n", i);

		ftStatus = FT_OpenEx(devInfo.Description, FT_OPEN_BY_DESCRIPTION, &ftHandle[i]);
		if (ftStatus != FT_OK) {
			printf("FT_OpenEx failed! Cannot open device by Description=%s", devInfo.Description);
			return false;
		}

		ftStatus = FT_ResetPort(ftHandle[i]);
		if (ftStatus != FT_OK) {
			printf("FT_ResetPort failed! Cannot reset port");
			return false;
		}

		printf("  Reset port\n");

		DWORD dwDriverVersion = 0;
		ftStatus = FT_GetDriverVersion(ftHandle[i], &dwDriverVersion);
		if (ftStatus != FT_OK) {
			printf("FT_GetDriverVersion failed! Device not working after reset port!\n");
			return false;
		}

		printf("  Device is functional after reset port\n");

		FT_Close(ftHandle[i]);
		ftHandle[i] = NULL;
	}

	return true;
}

bool FT4232_D2XX_CyclePort()
{
	FT_STATUS ftStatus = 0;
	FT_HANDLE ftHandle[4] = { NULL };

	DWORD dwNumDevices = 0;
	ftStatus = FT_CreateDeviceInfoList(&dwNumDevices);
	if (ftStatus != FT_OK) {
		printf("FT_CreateDeviceInfoList failed! No devices found!\n");
		return false;
	}

	if (dwNumDevices != 4) {
		printf("FT_CreateDeviceInfoList failed! A FT_4232 should have 4 devices enumerated!\n");
		return false;
	}

	for (DWORD i = 0; i<dwNumDevices; ++i) {
		FT_DEVICE_LIST_INFO_NODE devInfo;
		memset(&devInfo, 0, sizeof(devInfo));

		ftStatus = FT_GetDeviceInfoDetail(i, &devInfo.Flags, &devInfo.Type,
			&devInfo.ID, &devInfo.LocId,
			devInfo.SerialNumber,
			devInfo.Description,
			&devInfo.ftHandle);
		if (ftStatus != FT_OK) {
			printf("FT_GetDeviceInfoDetail failed!\n");
			return false;
		}

		printf("Dev %d:\n", i);

		ftStatus = FT_OpenEx(devInfo.Description, FT_OPEN_BY_DESCRIPTION, &ftHandle[i]);
		if (ftStatus != FT_OK) {
			printf("FT_OpenEx failed! Cannot open device by Description=%s", devInfo.Description);
			return false;
		}

		ftStatus = FT_CyclePort(ftHandle[i]);
		if (ftStatus != FT_OK) {
			printf("FT_CyclePort failed! Cannot cycle port");
			return false;
		}
		FT_Close(ftHandle[i]);
		ftHandle[i] = NULL;

		printf("  Cycle port\n");
		Sleep(3000);

		dwNumDevices = 0;
		while (1) {
			ftStatus = FT_ListDevices(&dwNumDevices, NULL, FT_LIST_NUMBER_ONLY);
			if (ftStatus != FT_OK) {
				printf("FT_ListDevices failed after cycle port!\n");
				return false;
			}
			if (dwNumDevices != 4) {
				continue;
			}
			break;
		}

		printf("  Device has reenumerated after cycle port\n");
		Sleep(3000);
		ftStatus = FT_CreateDeviceInfoList(&dwNumDevices);
		if (ftStatus != FT_OK) {
			printf("FT_CreateDeviceInfoList failed after cycle port!\n");
			return false;
		}
		if (dwNumDevices != 4) {
			printf("FT_CreateDeviceInfoList failed after cycle port! A FT_4232 should have 4 devices enumerated!\n");
			return false;
		}

		memset(&devInfo, 0, sizeof(devInfo));
		ftStatus = FT_GetDeviceInfoDetail(i, &devInfo.Flags, &devInfo.Type,
			&devInfo.ID, &devInfo.LocId,
			devInfo.SerialNumber,
			devInfo.Description,
			&devInfo.ftHandle);
		if (ftStatus != FT_OK) {
			printf("FT_GetDeviceInfoDetail failed after cycle port!\n");
			return false;
		}

		printf("  ID=0x%08x\n", devInfo.ID);
		printf("  SerialNumber=%s\n", devInfo.SerialNumber);
		printf("  Description=%s\n", devInfo.Description);

		if (devInfo.ID != FT4232_DEVINFO_ID) {
			printf("FT_GetDeviceInfoDetail failed after cycle port! Invalid ID detected!\n");
			return false;
		}

		ftStatus = FT_OpenEx(devInfo.Description, FT_OPEN_BY_DESCRIPTION, &ftHandle[i]);
		if (ftStatus != FT_OK) {
			printf("FT_OpenEx failed after cycle port! Cannot open device by Description=%s", devInfo.Description);
			return false;
		}

		printf("  Device can be opened after cycle port\n");
		FT_Close(ftHandle[i]);
		ftHandle[i] = NULL;
	}

	return true;
}

bool FT4232_D2XX_ResetDevice()
{
	FT_STATUS ftStatus = 0;
	FT_HANDLE ftHandle[4] = { NULL };

	DWORD dwNumDevices = 0;
	ftStatus = FT_CreateDeviceInfoList(&dwNumDevices);
	if (ftStatus != FT_OK) {
		printf("FT_CreateDeviceInfoList failed! No devices found!\n");
		return false;
	}

	if (dwNumDevices != 4) {
		printf("FT_CreateDeviceInfoList failed! A FT_4232 should have 4 devices enumerated!\n");
		return false;
	}

	for (DWORD i = 0; i<dwNumDevices; ++i) {
		FT_DEVICE_LIST_INFO_NODE devInfo;
		memset(&devInfo, 0, sizeof(devInfo));

		ftStatus = FT_GetDeviceInfoDetail(i, &devInfo.Flags, &devInfo.Type,
			&devInfo.ID, &devInfo.LocId,
			devInfo.SerialNumber,
			devInfo.Description,
			&devInfo.ftHandle);
		if (ftStatus != FT_OK) {
			printf("FT_GetDeviceInfoDetail failed!\n");
			return false;
		}

		printf("Dev %d:\n", i);

		ftStatus = FT_OpenEx(devInfo.Description, FT_OPEN_BY_DESCRIPTION, &ftHandle[i]);
		if (ftStatus != FT_OK) {
			printf("FT_OpenEx failed! Cannot open device by Description=%s", devInfo.Description);
			return false;
		}

		ftStatus = FT_ResetDevice(ftHandle[i]);
		if (ftStatus != FT_OK) {
			printf("FT_ResetDevice failed! Cannot reset device!");
			return false;
		}
		FT_Close(ftHandle[i]);
		ftHandle[i] = NULL;

		printf("  Reset device\n");
		//Sleep(3000);

		dwNumDevices = 0;
		while (1) {
			ftStatus = FT_ListDevices(&dwNumDevices, NULL, FT_LIST_NUMBER_ONLY);
			if (ftStatus != FT_OK) {
				printf("FT_ListDevices failed after reset device!\n");
				return false;
			}
			if (dwNumDevices != 4) {
				continue;
			}
			break;
		}

		printf("  Device has reenumerated after reset device\n");
		//Sleep(3000);

		ftStatus = FT_CreateDeviceInfoList(&dwNumDevices);
		if (ftStatus != FT_OK) {
			printf("FT_CreateDeviceInfoList failed after reset device!\n");
			return false;
		}
		if (dwNumDevices != 4) {
			printf("FT_CreateDeviceInfoList failed after reset device! A FT_4232 should have 4 devices enumerated!\n");
			return false;
		}

		memset(&devInfo, 0, sizeof(devInfo));
		ftStatus = FT_GetDeviceInfoDetail(i, &devInfo.Flags, &devInfo.Type,
			&devInfo.ID, &devInfo.LocId,
			devInfo.SerialNumber,
			devInfo.Description,
			&devInfo.ftHandle);
		if (ftStatus != FT_OK) {
			printf("FT_GetDeviceInfoDetail failed after reset device!\n");
			return false;
		}

		printf("  ID=0x%08x\n", devInfo.ID);
		printf("  SerialNumber=%s\n", devInfo.SerialNumber);
		printf("  Description=%s\n", devInfo.Description);

		if (devInfo.ID != FT4232_DEVINFO_ID) {
			printf("FT_GetDeviceInfoDetail failed after reset device! Invalid ID detected!\n");
			return false;
		}

		ftStatus = FT_OpenEx(devInfo.Description, FT_OPEN_BY_DESCRIPTION, &ftHandle[i]);
		if (ftStatus != FT_OK) {
			printf("FT_OpenEx failed after reset device! Cannot open device by Description=%s", devInfo.Description);
			return false;
		}

		printf("  Device can be opened after reset device\n");
		FT_Close(ftHandle[i]);
		ftHandle[i] = NULL;
	}

	return true;
}
