#include "TestSuite.h"



static void runTest(
	std::vector<TEST_CASE> bConfigtestCases, 
	bool bConfigFailThenStop,
	bool bConfigStressTest)
{
	std::vector<std::string> szTestCases;
	std::vector<bool> bTestResults;

	do {
		int idx = 0;
		for (auto & i : bConfigtestCases) {
			if (i.m_fxn == NULL) {
				break;
			}

			DisplayTestStart(i.m_dsc.c_str());
			szTestCases.push_back(i.m_dsc);
			bool bRet = i.m_fxn();
			bTestResults.push_back(bRet);

			DisplayTestStop(bRet);

			if (!bRet) {
				if (bConfigFailThenStop) {
					goto exit;
				}
			}

			idx++;
		}
	} while (bConfigStressTest);


exit:

	DisplayTestSummary(szTestCases, bTestResults);
	DisplayTestLogFile(LOGGER_FILE());
	LOGGER_FREE();
}

static const std::vector<std::string> g_szUsageCommands = { "mpsse", "loopback", "fastserial" };

static void showUsage(const char* pcFilename)
{
	CMD_LOG("--------------------------------------------------------------\n");
	CMD_LOG("USAGE\n");
	CMD_LOG("--------------------------------------------------------------\n");
	const char* ptr = strrchr((char*)pcFilename, '\\');
	if (ptr) {
		ptr++;
	}
	else {
		ptr = pcFilename;
	}
	CMD_LOG("%s --mode <MODE> --stress <FLAG> --failstop <FLAG>\n", ptr);
	CMD_LOG("  where MODE is 0 for mpsse, 1 for loopback, or 2 for fastserial\n");
	CMD_LOG("  where FLAG is 0 for disabled, or 1 for enabled\n");
	for (unsigned int j = 0; j < g_szUsageCommands.size(); j++) {
		CMD_LOG("  %s --mode %d\n", ptr, j);
		if (j == 0) {
			CMD_LOG("  %s --mode %d --failstop 0\n", ptr, j);
			CMD_LOG("  %s --mode %d --stress 1\n", ptr, j);
			CMD_LOG("  %s --mode %d --stress 1 --failstop 0\n", ptr, j);
		}
	}
	for (unsigned int j = 0; j < g_szUsageCommands.size(); j++) {
		CMD_LOG("  %s --mode %s\n", ptr, g_szUsageCommands[j].c_str());
		if (j == 0) {
			CMD_LOG("  %s --mode %s --failstop 0\n", ptr, g_szUsageCommands[j].c_str());
			CMD_LOG("  %s --mode %s --stress 1 \n", ptr, g_szUsageCommands[j].c_str());
			CMD_LOG("  %s --mode %s --stress 1 --failstop 0\n", ptr, g_szUsageCommands[j].c_str());
		}
	}
	CMD_LOG("\n");
	CMD_LOG("\n");
}

int main(int argc, char* argv[])
{
	std::vector<TEST_CASE> testCases = TEST_CONFIG_TEST_CASES;
	bool bFailThenStop = TEST_CONFIG_STOPWHENFAIL;
	bool bStressTest = TEST_CONFIG_STRESSTEST;
	const char* pcConfigFileName = (char*)TEST_CONFIG_LOG_FILE_NAME.c_str();
	LOGGER_INIT(pcConfigFileName, false);

	if (argc == 1) {
		showUsage(argv[0]);
		runTest(testCases, bFailThenStop, bStressTest);
		system("pause");
	}
	else {
		std::vector<std::string> args(argv + 1, argv + argc);
		for (std::vector<std::string>::iterator i = args.begin(); i != args.end(); ++i) {
			std::string option = *i;
			std::transform(option.begin(), option.end(), option.begin(), ::tolower);
			if (option == "-h" || option == "--help") {
				showUsage(argv[0]);
				return 0;
			}
			else if (option == "-m" || option == "--mode") {
				std::string val = *++i;
				std::transform(val.begin(), val.end(), val.begin(), ::tolower);
				if (val == "0" || val == g_szUsageCommands[0]) {
					testCases = TEST_CONFIG_TEST_CASES;
				}
				else if (val == "1" || val == g_szUsageCommands[1]) {
					testCases = TEST_CONFIG_TEST_CASES_2;
				}
				else if (val == "2" || val == g_szUsageCommands[2]) {
					testCases = TEST_CONFIG_TEST_CASES_3;
				}
			}
			else if (option == "-f" || option == "--failstop") {
				std::string val = *++i;
				if (val == "0") {
					bFailThenStop = false;
				}
				else if (val == "1") {
					bFailThenStop = true;
				}
			}
			else if (option == "-s" || option == "--stress") {
				std::string val = *++i;
				if (val == "0") {
					bStressTest = false;
				}
				else if (val == "1") {
					bStressTest = true;
				}
			}
			else {
				showUsage(argv[0]);
				return 0;
			}
		}
		runTest(testCases, bFailThenStop, bStressTest);
	}

	return 0;
}
