#include "ftd2xx.h"
#include "ftdiIds.h"
#include "../../TEST SUITE/TestLogger.h"
#pragma comment(lib, "ftd2xx.lib")
#include <stdio.h>
#include <conio.h>



// Can modify these macros
#define DISABLE_DATA_COMPARE 1	// Temporarily disabled until setup is not available
#define LOOPBACK_SIZE 4096		// Should be based on the available FIFO size

// Do not modify these macros
#define NUM_THREADS 2
#define THREAD_WRITER 0
#define THREAD_READER 1



static int getInput(DWORD dwNumDevices, const char* pcPromptMsg)
{
	CMD_LOG("%s", pcPromptMsg);

	int cInput = getc(stdin);
	int iDevIndex = -1;

	while (cInput != (int)'\n' || (iDevIndex < 0 || iDevIndex >= (int)dwNumDevices))
	{
		iDevIndex = cInput - '0';
		cInput = getc(stdin);
		if (cInput == '\n' && (iDevIndex < 0 || iDevIndex >= (int)dwNumDevices)) {
			CMD_LOG("%s", pcPromptMsg);
		}
	}

	return iDevIndex;
}

static bool getInputWithTimeout(int iTimeoutMs)
{
	HANDLE stdinHandle = GetStdHandle(STD_INPUT_HANDLE);
	switch (WaitForSingleObject(stdinHandle, iTimeoutMs)) {
		case(WAIT_OBJECT_0): {
			if (_kbhit()) {
				_getch();
				return true;
			}
			else {
				// clear events
				INPUT_RECORD r[512];
				DWORD read;
				ReadConsoleInput(stdinHandle, r, 512, &read);
				break;
			}
		}
		case(WAIT_TIMEOUT):
		case(WAIT_FAILED):
		case(WAIT_ABANDONED):
		default: {
			break;
		}
	}

	return false;
}
static bool openDevices(int iDevIndex1, int iDevIndex2, FT_HANDLE* pftHandle1, FT_HANDLE* pftHandle2)
{
	FT_STATUS ftStatus;

	ftStatus = FT_Open(iDevIndex1, pftHandle1);
	if (ftStatus != FT_OK) {
		CMD_LOG("FT_Open failed! Cannot open device by Index1=%d", iDevIndex1);
		return false;
	}

	if (iDevIndex2 != iDevIndex1) {
		ftStatus = FT_Open(iDevIndex2, pftHandle2);
		if (ftStatus != FT_OK) {
			CMD_LOG("FT_Open failed! Cannot open device by Index2=%d", iDevIndex2);
			return false;
		}
	}
	else {
		*pftHandle2 = *pftHandle1;
	}

	return true;
}

static void closeDevices(FT_HANDLE ftHandle1, FT_HANDLE ftHandle2)
{
	FT_STATUS ftStatus;

	if (ftHandle1 == ftHandle2) {
		ftStatus = FT_Close(ftHandle1);
	}
	else {
		ftStatus = FT_Close(ftHandle1);
		ftStatus = FT_Close(ftHandle2);
	}
}

static bool displayDevices(DWORD dwNumDevices)
{
	FT_STATUS ftStatus;

	for (DWORD i = 0; i<dwNumDevices; ++i) {
		FT_DEVICE_LIST_INFO_NODE devInfo;
		memset(&devInfo, 0, sizeof(devInfo));

		ftStatus = FT_GetDeviceInfoDetail(i, &devInfo.Flags, &devInfo.Type,
			&devInfo.ID, &devInfo.LocId,
			devInfo.SerialNumber,
			devInfo.Description,
			&devInfo.ftHandle);
		if (ftStatus != FT_OK) {
			CMD_LOG("FT_GetDeviceInfoDetail failed!\n");
			return false;
		}

		CMD_LOG("Dev %d:\n", i);
		CMD_LOG("  ID=0x%08x (%s)\n", devInfo.ID, FT_GetVidPidString(devInfo.ID));
		CMD_LOG("  LocId=0x%08x\n", devInfo.LocId);
		CMD_LOG("  Type=0x%08x\n", devInfo.Type);
		CMD_LOG("  Flags=0x%08x\n", devInfo.Flags);
		CMD_LOG("  SerialNumber=%s\n", devInfo.SerialNumber);
		CMD_LOG("  Description=%s\n", devInfo.Description);
	}

	CMD_LOG("\n");
	return true;
}

typedef enum {
	LoopbackWrite = 0,
	LoopbackRead,
	LoopbackCompare,
} LoopbackStatus;

typedef struct _ThreadParams 
{
	FT_HANDLE ftHandle;
	HANDLE* phMutex;
	bool* pbStop;
	bool* pbReadError;
	bool* pbWriteError;
	LoopbackStatus* pbStatus;
	int iBufSize;
	char* pcBuffer;

} ThreadParams;

DWORD WINAPI ThreadWriter(LPVOID lpParam) 
{
	ThreadParams* pThread = (ThreadParams*)lpParam;
	FT_STATUS ftStatus;
	DWORD dwCount = 0;
	DWORD dwWaitResult = 0;
	DWORD dwIteration = 0;
	CMD_LOG("ThreadWriter started..\n");


	ftStatus = FT_SetTimeouts(pThread->ftHandle, 0, 1000);
	if (ftStatus != FT_OK) {
		CMD_LOG("ThreadWriter FT_SetTimeouts failed!\n");
		return 0;
	}

	while (!(*pThread->pbStop)) {
		dwWaitResult = WaitForSingleObject(*pThread->phMutex, 1000);
		if (*pThread->pbStop) {
			CMD_LOG("ThreadWriter aborted!\n");
			return 0;
		}
		switch (dwWaitResult) {
			case WAIT_OBJECT_0: {
				CMD_LOG("ThreadWriter mutex get... [%d]\n", dwIteration++);
				try {
					if (*pThread->pbStatus != LoopbackWrite) {
						CMD_LOG("ThreadWriter invalid status detected! %d\n", *pThread->pbStatus);
						CMD_LOG("ThreadWriter mutex released...\n");
						ReleaseMutex(*pThread->phMutex);
						Sleep(1000);
						break;
					}

					DWORD dwBytesTransferred = 0;

					ftStatus = FT_Write(pThread->ftHandle, pThread->pcBuffer, pThread->iBufSize, &dwBytesTransferred);
					if (ftStatus != FT_OK) {
						CMD_LOG("ThreadWriter FT_Write failed! ftStatus = 0x%08x\n", ftStatus);
						*pThread->pbWriteError = true;
						ReleaseMutex(*pThread->phMutex);
						goto exit;
					}
					else {
#if DISABLE_DATA_COMPARE
						Sleep(250);
#else // DISABLE_DATA_COMPARE
						if (dwBytesTransferred != pThread->iBufSize) {
							CMD_LOG("ThreadWriter FT_Write failed! dwBytesTransferred(%d) != pThread->iBufSize(%d)\n", dwBytesTransferred, pThread->iBufSize);
						}
#endif // DISABLE_DATA_COMPARE

						*pThread->pbStatus = LoopbackRead;
					}
				}
				catch (...) {
					CMD_LOG("ThreadWriter mutex released...\n");
					ReleaseMutex(*pThread->phMutex);
					goto exit;
				}
				CMD_LOG("ThreadWriter mutex released...\n");
				ReleaseMutex(*pThread->phMutex);
				break;
			}
			case WAIT_ABANDONED: {
				CMD_LOG("ThreadWriter aborted!\n");
				return 0;
			}
		}
	}

exit:
	CMD_LOG("ThreadWriter completed!\n");
	return 0;
}

DWORD WINAPI ThreadReader(LPVOID lpParam)
{
	ThreadParams* pThread = (ThreadParams*)lpParam;
	FT_STATUS ftStatus;
	DWORD dwCount = 0;
	DWORD dwWaitResult = 0;
	DWORD dwIteration = 0;
	CMD_LOG("ThreadReader started...\n");


	char* pcBuffer = (char*)malloc(pThread->iBufSize);
	if (!pcBuffer) {
		CMD_LOG("ThreadReader malloc failed!\n");
		return 0;
	}

	ftStatus = FT_SetTimeouts(pThread->ftHandle, 1000, 0);
	if (ftStatus != FT_OK) {
		CMD_LOG("ThreadReader FT_SetTimeouts failed!\n");
		goto exit;
	}

	while (!(*pThread->pbStop)) {
		dwWaitResult = WaitForSingleObject(*pThread->phMutex, 1000);
		if (*pThread->pbStop) {
			CMD_LOG("ThreadReader aborted!\n");
			goto exit;
		}
		switch (dwWaitResult) {
			case WAIT_OBJECT_0: {
				CMD_LOG("ThreadReader mutex get... [%d]\n", dwIteration++);
				try {
					if (*pThread->pbStatus != LoopbackRead) {
						CMD_LOG("ThreadReader invalid status detected! %d\n", *pThread->pbStatus);
						CMD_LOG("ThreadReader mutex released...\n");
						ReleaseMutex(*pThread->phMutex);
						Sleep(1000);
						break;
					}

					DWORD dwBytesTransferred = 0;

					ftStatus = FT_Read(pThread->ftHandle, pcBuffer, pThread->iBufSize, &dwBytesTransferred);
					if (ftStatus != FT_OK) {
						CMD_LOG("ThreadReader FT_Read failed! ftStatus = 0x%08x\n", ftStatus);
						*pThread->pbReadError = true;
						ReleaseMutex(*pThread->phMutex);
						goto exit;
					}
					else {
						*pThread->pbStatus = LoopbackCompare;

#if DISABLE_DATA_COMPARE
						Sleep(250);
#else // DISABLE_DATA_COMPARE
						if (dwBytesTransferred != pThread->iBufSize) {
							CMD_LOG("ThreadReader FT_Read failed! dwBytesTransferred(%d) != pThread->iBufSize(%d)\n", dwBytesTransferred, pThread->iBufSize);
						}

						if (memcmp(pcBuffer, pThread->pcBuffer, pThread->iBufSize) != 0) {
							CMD_LOG("ThreadReader memcmp failed! Data mismatch!\n", dwBytesTransferred, pThread->iBufSize);
							*pThread->pbReadError = true;
							ReleaseMutex(*pThread->phMutex);
							goto exit;
						}
#endif // DISABLE_DATA_COMPARE

						*pThread->pbStatus = LoopbackWrite;
					}
				}
				catch (...) {
					CMD_LOG("ThreadReader mutex released...\n");
					ReleaseMutex(*pThread->phMutex);
					goto exit;
				}
				CMD_LOG("ThreadReader mutex released...\n");
				ReleaseMutex(*pThread->phMutex);
				break;
			}
			case WAIT_ABANDONED: {
				CMD_LOG("ThreadReader aborted!\n");
				goto exit;
			}
		}
	}

exit:
	if (pcBuffer) {
		free(pcBuffer);
		pcBuffer = NULL;
	}

	CMD_LOG("ThreadReader completed!\n");
	return 0;
}

static bool DoLoopback(int iDevIndex, int iDevIndex2)
{
	DWORD dwWaitResult = 0;
	bool bRet = false;
	HANDLE hThreads[NUM_THREADS] = { NULL };
	LPTHREAD_START_ROUTINE fxnThreads[NUM_THREADS] = { ThreadWriter, ThreadReader };
	ThreadParams hParams[NUM_THREADS] = { 0 };

	FT_HANDLE ftHandle[NUM_THREADS] = { NULL, NULL };
	HANDLE hMutex = NULL;
	bool bStop = false;
	LoopbackStatus bStatus = LoopbackWrite;
	bool bWriteError = false;
	bool bReadError = false;
	int iBufSize = LOOPBACK_SIZE;
	char cBuffer[LOOPBACK_SIZE] = { 0 };


	bRet = openDevices(iDevIndex, iDevIndex2, &ftHandle[THREAD_WRITER], &ftHandle[THREAD_READER]);
	if (!bRet) {
		CMD_LOG("Cannot open the loopback devices!\n");
		return false;
	}

	hMutex = CreateMutex(NULL, FALSE, NULL);
	if (!hMutex) {
		CMD_LOG("Cannot create mutex for the loopback devices!\n");
		goto exit;
	}

	for (int i = 0; i < NUM_THREADS; i++) {
		hParams[i].ftHandle = ftHandle[i];
		hParams[i].phMutex = &hMutex;
		hParams[i].pbStop = &bStop;
		hParams[i].pbStatus = &bStatus;
		hParams[i].pbWriteError = &bWriteError;
		hParams[i].pbReadError = &bReadError;
		hParams[i].iBufSize = iBufSize;
		hParams[i].pcBuffer = &cBuffer[0];
		hThreads[i] = CreateThread(NULL, 0, fxnThreads[i], &hParams[i], 0, NULL);
		if (hThreads[i] == NULL) {
			CMD_LOG("Cannot create thread[%d]!\n", i);
			goto exit;
		}
		Sleep(1);
	}

	CMD_LOG("Press any key to stop the threads.\n");
	while (true) {
		dwWaitResult = WaitForMultipleObjects(NUM_THREADS, hThreads, TRUE, 1000);
		switch (dwWaitResult) {
			case WAIT_TIMEOUT: {
				if (!bWriteError && !bReadError) {
					CMD_LOG("Press any key to stop the threads.\n");
				}
				break;
			}
			case WAIT_OBJECT_0: {
				CMD_LOG("The threads have aborted!\n");
				goto exit;
			}
			case WAIT_ABANDONED: {
				CMD_LOG("WaitForMultipleObjects WAIT_ABANDONED\n");
				goto exit;
			}
		}
		if (bWriteError) {
			CMD_LOG("Writer thread failed. Sending abort signal now!\n");
			bStop = true;
		}
		if (bReadError) {
			CMD_LOG("Reader thread failed. Sending abort signal now!\n");
			bStop = true;
		}
		if (getInputWithTimeout(500)) {
			CMD_LOG("A key was pressed. Sending abort signal now!\n");
			bStop = true;
		}
	}

exit:

	if (hMutex != NULL) {
		CloseHandle(hMutex);
		hMutex = NULL;
	}

	for (int i = 0; i<NUM_THREADS; i++) {
		if (hThreads[i] != NULL) {
			CloseHandle(hThreads[i]);
			hThreads[i] = NULL;
		}
	}

	closeDevices(ftHandle[THREAD_WRITER], ftHandle[THREAD_READER]);

	return (!bWriteError && !bReadError);
}

bool FT4232_LOOPBACK_2Threads2Devices() {

	bool bRet = false;
	FT_STATUS ftStatus = 0;
	DWORD dwNumDevices = 0;

	do {
		ftStatus = FT_ListDevices(&dwNumDevices, NULL, FT_LIST_NUMBER_ONLY);
		if (ftStatus != FT_OK) {
			CMD_LOG("FT_ListDevices failed after cycle port!\n");
			return false;
		}
		if (dwNumDevices == 0) {
			CMD_LOG("No devices detected!\n", dwNumDevices);
			CMD_LOG("Please connect the 2 loopback devices and press any key\n");
			system("pause");
			CMD_LOG("\n");
		}
	} while (dwNumDevices == 0);

	ftStatus = FT_CreateDeviceInfoList(&dwNumDevices);
	if (ftStatus != FT_OK) {
		CMD_LOG("FT_CreateDeviceInfoList failed! No devices found!\n");
		return false;
	}

	CMD_LOG("DeviceCount=%d\n", dwNumDevices);
	
	bRet = displayDevices(dwNumDevices);
	if (!bRet) {
		CMD_LOG("Cannot enumerate the devices connected!\n");
		return false;
	}

	int iDevIndex = getInput(dwNumDevices, "Please enter the index of the 1st loopback device: ");
	int iDevIndex2 = getInput(dwNumDevices, "Please enter the index of the 2nd loopback device: ");
	CMD_LOG("1st device=%d 2nd device=%d\n\n", iDevIndex, iDevIndex2);
	return DoLoopback(iDevIndex, iDevIndex2);
}
