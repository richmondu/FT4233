#include "../TEST SUITE/TestSuite.h"
#include "../TEST CASES/TestCases.h"
#include "../TEST SUITE/TestExamples.h"



// Define to use specific tests
#define SAMPLES_TESTS					0
#define D2XX_TESTS						1
#define MPSSE_I2C_TESTS					1
#define MPSSE_I2C_EEPROM24LC024H_TESTS	0 // enable only if you have I2C EEPROM 24LC024H
#define MPSSE_SPI_TESTS					1
#define MPSSE_SPI_EEPROM93LC56B_TESTS	0 // enable only if you have SPI EEPROM 93LC56B
#define LOOPBACK_TESTS					0



// Update to customize the file name of the log file
std::string TEST_CONFIG_LOG_FILE_NAME = "TestSuite_FT4232.log";

// Update to stop loop after some test failed
bool TEST_CONFIG_STOPWHENFAIL = false;

// Update to continuously run the test
bool TEST_CONFIG_STRESSTEST = false;



// Update to include all the test cases
std::vector<TEST_CASE> TEST_CONFIG_TEST_CASES =
{
#if SAMPLES_TESTS
	{ ExampleTest1, "ExampleTest1" },
	{ ExampleTest2, "ExampleTest2" },
	{ ExampleTest3, "ExampleTest3" },
#endif //SAMPLES_TESTS

	// -------------------------------------------------------------
	// Add test cases below ...
	// -------------------------------------------------------------

#if D2XX_TESTS
	{ FT4232_D2XX_Info,				"FT4232_D2XX_Info"				},
	{ FT4232_D2XX_Enumerate,		"FT4232_D2XX_Enumerate"			},
	{ FT4232_D2XX_Open,				"FT4232_D2XX_Open"				},
	{ FT4232_D2XX_ResetPort,		"FT4232_D2XX_ResetPort"			},
	{ FT4232_D2XX_CyclePort,		"FT4232_D2XX_CyclePort"			},
	{ FT4232_D2XX_ResetDevice,		"FT4232_D2XX_ResetDevice"		},
	//{ FT4232_D2XX_UART,				"FT4232_D2XX_UART"				},
#endif // D2XX_TESTS

#if MPSSE_I2C_TESTS
	{ FT4232_MPSSE_I2C_Enumerate,			"FT4232_MPSSE_I2C_Enumerate"			},
	{ FT4232_MPSSE_I2C_Open,				"FT4232_MPSSE_I2C_Open"					},
	{ FT4232_MPSSE_I2C_Configure,			"FT4232_MPSSE_I2C_Configure"			},
#if MPSSE_I2C_EEPROM24LC024H_TESTS
	{ FT4232_MPSSE_I2C_IO_EEPROM24LC024H,	"FT4232_MPSSE_I2C_IO_EEPROM24LC024H"	},
#endif // MPSSE_I2C_EEPROM24LC024H_TESTS
	{ FT4232_MPSSE_I2C_GPIO,				"FT4232_MPSSE_I2C_GPIO"					},
#endif // MPSSE_I2C_TESTS

#if MPSSE_SPI_TESTS
	{ FT4232_MPSSE_SPI_Enumerate,			"FT4232_MPSSE_SPI_Enumerate"			},
	{ FT4232_MPSSE_SPI_Open,				"FT4232_MPSSE_SPI_Open"					},
	{ FT4232_MPSSE_SPI_Configure,			"FT4232_MPSSE_SPI_Configure"			},
#if MPSSE_SPI_EEPROM93LC56B_TESTS
	{ FT4232_MPSSE_SPI_IO_EEPROM93LC56B,	"FT4232_MPSSE_SPI_IO_EEPROM93LC56B"		},
#endif // MPSSE_SPI_EEPROM93LC56B_TESTS
	{ FT4232_MPSSE_SPI_GPIO,				"FT4232_MPSSE_SPI_GPIO"					},
#endif // MPSSE_SPI_TESTS

#if LOOPBACK_TESTS
	{ FT4232_LOOPBACK_2Threads2Devices,		"FT4232_LOOPBACK_2Threads2Devices"		},
#endif // LOOPBACK_TESTS

	// -------------------------------------------------------------
	// Add test cases above ...
	// -------------------------------------------------------------

	{ NULL, "" }, // Do not modify. Last test case should be NULL.
};

std::vector<TEST_CASE> TEST_CONFIG_TEST_CASES_2 =
{
	{ FT4232_LOOPBACK_2Threads2Devices,		"FT4232_LOOPBACK_2Threads2Devices"		},
	{ NULL, "" }, // Do not modify. Last test case should be NULL.
};

std::vector<TEST_CASE> TEST_CONFIG_TEST_CASES_3 =
{
	{ NULL, "" }, // Do not modify. Last test case should be NULL.
};
