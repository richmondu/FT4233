#pragma once

// From ftd2xxTest.cpp
bool FT4232_D2XX_Info();
bool FT4232_D2XX_Enumerate();
bool FT4232_D2XX_Open();
bool FT4232_D2XX_ResetPort();
bool FT4232_D2XX_CyclePort();
bool FT4232_D2XX_ResetDevice();
bool FT4232_D2XX_UART();
bool FT4232_D2XX_GPIO();

// From mpsseI2CTest.cpp
bool FT4232_MPSSE_I2C_Enumerate();
bool FT4232_MPSSE_I2C_Open();
bool FT4232_MPSSE_I2C_Configure();
bool FT4232_MPSSE_I2C_IO_EEPROM24LC024H();
bool FT4232_MPSSE_I2C_GPIO();

// From mpsseSPITest.cpp
bool FT4232_MPSSE_SPI_Enumerate();
bool FT4232_MPSSE_SPI_Open();
bool FT4232_MPSSE_SPI_Configure();
bool FT4232_MPSSE_SPI_IO_EEPROM93LC56B();
bool FT4232_MPSSE_SPI_GPIO();

// From loopbacktest.cpp
bool FT4232_LOOPBACK_2Threads2Devices();
