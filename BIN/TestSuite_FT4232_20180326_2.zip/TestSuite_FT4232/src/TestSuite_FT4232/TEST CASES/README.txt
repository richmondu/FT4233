Notes:

1. Do not update any of the files in TEST SUITE

2. Update macro values in TESTCASES.cpp to customize the tests covered

   #define SAMPLES_TESTS			0
   #define D2XX_TESTS				1
   #define MPSSE_I2C_TESTS			1
   #define MPSSE_I2C_EEPROM24LC024H_TESTS	0 // enable only if you have I2C EEPROM 24LC024H
   #define MPSSE_SPI_TESTS			1
   #define MPSSE_SPI_EEPROM93LC56B_TESTS	0 // enable only if you have SPI EEPROM 93LC56B

3. When adding new test cases, declare the new test functions in TESTCASES.cpp and TESTCASES.h.
   The new test functions can be defined in new files or existing files: 
   mpsseI2CTest.cpp, mpsseSPITest.cpp and ftd2xxTest.cpp