#pragma once
#include <string>
#include <vector>
#include "TestLogger.h"
#include "TestOutput.h"



typedef bool(*TEST_FUNCTION)();

typedef struct _TEST_CASE
{
	TEST_FUNCTION	m_fxn;
	std::string		m_dsc;

} TEST_CASE;

extern std::string TEST_CONFIG_LOG_FILE_NAME;

extern std::vector<TEST_CASE> TEST_CONFIG_TEST_CASES;

extern bool TEST_CONFIG_STOPWHENFAIL;

extern bool TEST_CONFIG_STRESSTEST;
