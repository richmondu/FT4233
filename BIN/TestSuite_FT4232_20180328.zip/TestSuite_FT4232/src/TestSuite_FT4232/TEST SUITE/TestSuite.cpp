#include "TestSuite.h"



int main()
{
	bool bConfigStopWhenFail = TEST_CONFIG_STOPWHENFAIL;
	bool bConfigStressTest = TEST_CONFIG_STRESSTEST;
	char* pcConfigFileName = (char*)TEST_CONFIG_LOG_FILE_NAME.c_str();
	bool* pbTestResult = new bool[TEST_CONFIG_TEST_CASES.size()];

	LOGGER_INIT(pcConfigFileName, false);

	do {
		int idx = 0;
		for (auto & i : TEST_CONFIG_TEST_CASES) {
			if (i.m_fxn == NULL) {
				break;
			}

			DisplayTestStart(i.m_dsc.c_str());
			pbTestResult[idx] = i.m_fxn();
			DisplayTestStop(pbTestResult[idx]);

			if (!pbTestResult[idx]) {
				if (bConfigStopWhenFail) {
					goto exit;
				}
			}

			idx++;
		}
	} while (bConfigStressTest);


exit:

	DisplayTestSummary(pbTestResult);
	DisplayTestLogFile(LOGGER_FILE());
	LOGGER_FREE();
	delete pbTestResult;

	system("pause");
	return 0;
}
