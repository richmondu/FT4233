#pragma once

bool ExampleTest1();
bool ExampleTest2();
bool ExampleTest3();
