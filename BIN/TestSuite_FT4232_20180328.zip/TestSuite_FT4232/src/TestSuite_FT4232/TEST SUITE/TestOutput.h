#pragma once
#include "TestSuite.h"
#include <vector>
using namespace std;

void DisplayTestStart(const char* a_pcDescription);
void DisplayTestStop(bool a_bStatus);
void DisplayTestSummary(bool* pbTestResult);
void DisplayTestLogFile(const char* a_pcFileName);
